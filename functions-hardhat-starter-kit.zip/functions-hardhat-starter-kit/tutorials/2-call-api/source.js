const url = `https://mg2yn0yc91.execute-api.us-east-2.amazonaws.com/Test/sensor?id=48307-0001`
const DeviceDataRequest = Functions.makeHttpRequest({
  url: url,
})

const DeviceData = await DeviceDataRequest
if (DeviceData.error) {
  console.error(DeviceData.error)
  throw Error("Request failed")
}

const data = DeviceData["data"]

console.log(data)

return Functions.encodeString(JSON.stringify(data))